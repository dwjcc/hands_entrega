import 'package:flutter/material.dart';

import 'package:meu_primeiro_app/meu_primeiro_app.dart';

void main() {
  runApp(const MeuPrimeiroApp());
}